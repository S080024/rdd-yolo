import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.layers import CondConv2d
from ultralytics.nn.modules.conv import DWConv
from ultralytics.utils.tal import dist2bbox, make_anchors

__all__ = ['Detect_dyhead']


def _make_divisible(v, divisor, min_value=None):
    if min_value is None:
        min_value = divisor
    new_v = max(min_value, int(v + divisor / 2) // divisor * divisor)
    if new_v < 0.9 * v:
        new_v += divisor
    return new_v


def _adjust_channels(c, g):
    """调整通道数使其能被组数整除，且不小于组数"""
    if c % g != 0:
        c = (c // g + 1) * g
    return max(c, g)


class DynamicConv(nn.Module):
    def __init__(self, in_features, out_features, kernel_size=1, stride=1, padding='', dilation=1,
                 groups=1, bias=False, num_experts=4):
        super().__init__()
        # 确保输入输出通道数能被分组数整除
        in_features = _adjust_channels(in_features, groups)
        out_features = _adjust_channels(out_features, groups)
        
        self.routing = nn.Linear(in_features, num_experts)
        self.cond_conv = CondConv2d(in_features, out_features, kernel_size, stride, padding, dilation,
                                    groups, bias, num_experts)

    def forward(self, x):
        pooled_inputs = F.adaptive_avg_pool2d(x, 1).flatten(1)
        routing_weights = torch.sigmoid(self.routing(pooled_inputs))
        x = self.cond_conv(x, routing_weights)
        return x


def autopad(k, p=None, d=1):
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p


class DEConv_GN(nn.Module):
    """带GroupNorm的转置卷积模块，用于替换分类分支的GroupNormConv"""
    default_act = nn.SiLU()

    def __init__(self, c1, c2, k=3, s=1, p=None, act=True, num_groups=32):
        super().__init__()
        # 1. 确保分组数有效（不超过输出通道数，且能整除输出通道数）
        self.num_groups = min(num_groups, c2)
        self.num_groups = self._get_valid_groups(c2, self.num_groups)
        
        # 2. 调整输出通道数，确保能被分组数整除
        self.c2 = _adjust_channels(c2, self.num_groups)
        
        # 3. 定义转置卷积+GroupNorm+激活
        self.deconv = nn.ConvTranspose2d(c1, self.c2, k, s, autopad(k, p))
        self.gn = nn.GroupNorm(self.num_groups, self.c2)
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def _get_valid_groups(self, c, g):
        """寻找能整除通道数c的最大分组数（不超过g）"""
        if c % g == 0:
            return g
        for i in range(g, 0, -1):
            if c % i == 0:
                return i
        return 1

    def forward(self, x):
        return self.act(self.gn(self.deconv(x)))


class DFL(nn.Module):
    def __init__(self, c1=16):
        super().__init__()
        self.conv = nn.Conv2d(c1, 1, 1, bias=False).requires_grad_(False)
        x = torch.arange(c1, dtype=torch.float)
        self.conv.weight.data[:] = nn.Parameter(x.view(1, c1, 1, 1))
        self.c1 = c1

    def forward(self, x):
        b, c, a = x.shape
        return self.conv(x.view(b, 4, self.c1, a).transpose(2, 1).softmax(1)).view(b, 4, a)


class ELA(nn.Module):
    def __init__(self, in_channels, phi='T'):
        super(ELA, self).__init__()
        Kernel_size = {'T': 5, 'B': 7, 'S': 5, 'L': 7}[phi]
        groups = {'T': in_channels, 'B': in_channels, 'S': in_channels // 8, 'L': in_channels // 8}[phi]
        default_num_groups = {'T': 32, 'B': 16, 'S': 16, 'L': 16}[phi]
        
        # 确保分组数有效
        self.num_groups = self._get_valid_groups(in_channels, default_num_groups)
        groups = self._get_valid_groups(in_channels, groups)
        
        pad = Kernel_size // 2
        self.con1 = nn.Conv1d(in_channels, in_channels, kernel_size=Kernel_size, padding=pad, groups=groups, bias=False)
        self.GN = nn.GroupNorm(self.num_groups, in_channels)
        self.sigmoid = nn.Sigmoid()
    
    def _get_valid_groups(self, in_channels, default_num):
        if in_channels % default_num == 0:
            return default_num
        for g in range(default_num - 1, 0, -1):
            if in_channels % g == 0:
                return g
        return 1
    
    def forward(self, input):
        b, c, h, w = input.size()
        x_h = torch.mean(input, dim=3, keepdim=True).view(b, c, h)
        x_w = torch.mean(input, dim=2, keepdim=True).view(b, c, w)
        x_h = self.con1(x_h)
        x_w = self.con1(x_w)
        x_h = self.sigmoid(self.GN(x_h)).view(b, c, h, 1)
        x_w = self.sigmoid(self.GN(x_w)).view(b, c, 1, w)
        return x_h * x_w * input


class Detect_dyhead(nn.Module):
    dynamic = False
    export = False
    shape = None
    anchors = torch.empty(0)
    strides = torch.empty(0)

    def __init__(self, nc=80, ch=()):
        super().__init__()
        self.nc = nc  # 类别数（默认80类）
        self.nl = len(ch)  # 特征层数量（P3/P4/P5共3层）
        self.reg_max = 16  # DFL的分布维度
        self.no = nc + self.reg_max * 4  # 每个锚点的输出维度（类别+4×分布）
        self.stride = torch.zeros(self.nl)  # 各层步长（后续初始化）
        
        # 全局分组数（统一用于所有GroupNorm相关模块）
        self.num_groups = 32
        
        # 计算并调整核心通道数（确保能被分组数整除）
        c2_base = max((16, ch[0] // 4, self.reg_max * 4))  # 回归分支基础通道数
        c3_base = max(ch[0], min(self.nc, 100))  # 分类分支基础通道数
        self.c2 = _adjust_channels(c2_base, self.num_groups)  # 回归分支最终通道数
        self.c3 = _adjust_channels(c3_base, self.num_groups)  # 分类分支最终通道数
        
        # 1. P3/P4/P5检测层与检测头之间的过渡层：Conv_GN（1×1卷积+GroupNorm）
        # （此处复用DEConv_GN，通过k=1实现1×1转置卷积，等价于普通卷积）
        self.conv_gn = nn.ModuleList(
            DEConv_GN(x, x, k=1, num_groups=self.num_groups)  # k=1时转置卷积≈普通卷积
            for x in ch
        )
        
        # 2. 回归分支（cv2）：预测边界框分布特征（4×reg_max通道）
        self.cv2 = nn.ModuleList(
            nn.Sequential(
                DynamicConv(x, self.c2, groups=1),  # 动态卷积调整通道
                ELA(in_channels=self.c2, phi='T'),  # 通道注意力增强
                DynamicConv(self.c2, self.c2, groups=1),  # 二次动态卷积
                ELA(in_channels=self.c2, phi='T'),  # 二次注意力增强
                nn.Conv2d(self.c2, 4 * self.reg_max, 1)  # 输出回归特征
            )
            for x in ch
        )
        
        # 3. 分类分支（cv3）：预测类别得分（nc通道）—— 核心修改：GroupNormConv→DEConv_GN
        self.cv3 = nn.ModuleList(
            nn.Sequential(
                # 第一子模块：DWConv → ELA → DEConv_GN（替换原GroupNormConv）
                nn.Sequential(
                    DWConv(x, x, 3),  # 深度卷积提取局部特征
                    ELA(in_channels=x, phi='T'),  # 注意力增强
                    DEConv_GN(x, self.c3, k=1, num_groups=self.num_groups)  # 1×1转置卷积调整通道
                ),
                # 第二子模块：DWConv → ELA → DEConv_GN（替换原GroupNormConv）
                nn.Sequential(
                    DWConv(self.c3, self.c3, 3),  # 深度卷积进一步提取特征
                    ELA(in_channels=self.c3, phi='T'),  # 注意力增强
                    DEConv_GN(self.c3, self.c3, k=1, num_groups=self.num_groups)  # 1×1转置卷积保持通道
                ),
                nn.Conv2d(self.c3, self.nc, 1)  # 输出分类特征（nc通道）
            )
            for x in ch
        )
        
        # DFL模块：将回归分支的分布特征转换为边界框偏移
        self.dfl = DFL(self.reg_max) if self.reg_max > 1 else nn.Identity()

    def forward(self, x):
        shape = x[0].shape  # 记录输入特征图形状（B, C, H, W）
        # 遍历P3/P4/P5各层，执行“过渡层→双分支→特征拼接”
        for i in range(self.nl):
            x[i] = self.conv_gn[i](x[i])  # 检测层→检测头过渡（Conv_GN）
            x[i] = torch.cat((self.cv2[i](x[i]), self.cv3[i](x[i])), 1)  # 拼接回归+分类特征
        
        # 训练阶段：直接输出各层特征（用于计算损失）
        if self.training:
            return x
        
        # 推理阶段：动态计算锚点和步长（首次推理或形状变化时）
        elif self.dynamic or self.shape != shape:
            self.anchors, self.strides = (x.transpose(0, 1) for x in make_anchors(x, self.stride, 0.5))
            self.shape = shape

        # 多尺度特征拼接（B, no, H1×W1 + H2×W2 + H3×W3）
        x_cat = torch.cat([xi.view(shape[0], self.no, -1) for xi in x], 2)
        # 拆分回归特征和分类特征
        box_feat, cls_feat = x_cat.split((self.reg_max * 4, self.nc), 1)
        
        # 回归特征后处理：DFL→边界框坐标
        dbox = dist2bbox(self.dfl(box_feat), self.anchors.unsqueeze(0), xywh=True, dim=1) * self.strides
        # 分类特征后处理：sigmoid转换为概率
        cls_prob = cls_feat.sigmoid()
        
        # 导出为特定格式时（如TFLite），归一化边界框到[0,1]
        if self.export and self.format in ("tflite", "edgetpu"):
            img_h, img_w = shape[2] * self.strides[0], shape[3] * self.strides[0]
            img_size = torch.tensor([img_w, img_h, img_w, img_h], device=dbox.device).reshape(1, 4, 1)
            dbox /= img_size
        
        # 拼接边界框和类别概率，得到最终检测结果
        y = torch.cat((dbox, cls_prob), 1)
        return y if self.export else (y, x)

    def bias_init(self):
        """初始化分支输出层偏置，加速训练收敛"""
        for reg_branch, cls_branch, stride in zip(self.cv2, self.cv3, self.stride):
            # 回归分支偏置初始化（设为1.0，对应边界框初始偏移）
            reg_branch[-1].bias.data[:] = 1.0
            # 分类分支偏置初始化（基于类别数和步长的对数初始化）
            cls_branch[-1].bias.data[:self.nc] = math.log(5 / self.nc / (640 / stride) ** 2)




















































































































































































































































































































































