from torch import nn
import torch
from einops import rearrange


# 可序列化的稳定激活包装器
class StableActivation(nn.Module):
    def __init__(self, base_act):
        super().__init__()
        self.base_act = base_act
    
    def forward(self, x):
        # 激活前裁剪
        if isinstance(self.base_act, (nn.SiLU, nn.ReLU)):
            x = x.clamp(min=-1e4, max=1e4)
        # 执行激活
        out = self.base_act(x)
        # 激活后裁剪
        if torch.isnan(out).any() or torch.isinf(out).any():
            out = out.clamp(min=-1e4, max=1e4)
        return out


# 基础卷积
def autopad(k, p=None, d=1):
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p

class Conv(nn.Module):
    default_act = nn.SiLU()
    
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = self._init_activation(act)
    
    def _init_activation(self, act):
        if act is False or act is None:
            return nn.Identity()
        if act is True:
            base_act = self.default_act
        elif isinstance(act, nn.Module):
            base_act = act
        else:
            raise ValueError(f"不支持的激活类型: {type(act)}")
        return StableActivation(base_act)
    
    def forward(self, x):
        # 输入异常处理（无打印）
        if torch.isnan(x).any() or torch.isinf(x).any():
            x = x.clamp(min=-1e4, max=1e4)
        out = self.conv(x)
        out = self.bn(out)
        out = self.act(out)
        return out


# 轻量化自适应核卷积（DRPAKConv）
class DRPAKConv(nn.Module):
    def __init__(self, inc, outc, num_param, stride=1, groups=1, bias=None):
        super(DRPAKConv, self).__init__()
        self.num_param = num_param
        self.stride = stride
        self.groups = groups
        
        if groups > inc:
            raise ValueError(f"分组数{groups}大于输入通道数{inc}")
        
        self.sample_conv_branch = nn.Sequential(
            nn.Conv2d(inc, inc, kernel_size=(num_param, 1), stride=(num_param, 1),
                      groups=inc, bias=bias),
            nn.BatchNorm2d(inc),
            nn.SiLU(),
            nn.Conv2d(inc, outc, kernel_size=1, stride=1, groups=groups, bias=bias),
            nn.BatchNorm2d(outc),
            nn.SiLU()
        )
        
        self.dw_pw_branch = nn.Sequential(
            nn.Conv2d(inc, inc, kernel_size=3, stride=stride, padding=autopad(3), 
                      groups=inc, bias=bias),
            nn.BatchNorm2d(inc),
            nn.ReLU(inplace=False),
            nn.Conv2d(inc, outc, kernel_size=1, stride=1, groups=groups, bias=bias),
            nn.BatchNorm2d(outc),
            nn.ReLU(inplace=False)
        )
        
        reduce_ch = max(inc // 4, 16)
        self.offset_predict = nn.Sequential(
            nn.Conv2d(inc, reduce_ch, kernel_size=1, stride=1, bias=bias),
            nn.BatchNorm2d(reduce_ch),
            nn.SiLU(),
            nn.Conv2d(reduce_ch, reduce_ch, kernel_size=3, padding=1, stride=stride,
                      groups=reduce_ch, bias=bias),
            nn.BatchNorm2d(reduce_ch),
            nn.SiLU(),
            nn.Conv2d(reduce_ch, 2 * num_param, kernel_size=1, stride=1, bias=bias),
            nn.Hardtanh(min_val=-2.0, max_val=2.0)
        )
        nn.init.constant_(self.offset_predict[-2].weight, 0)
        if bias and hasattr(self.offset_predict[-2], 'bias'):
            nn.init.constant_(self.offset_predict[-2].bias, 0)
        
        self.offset_predict.register_full_backward_hook(self._set_offset_lr)

    @staticmethod
    def _set_offset_lr(module, grad_input, grad_output):
        adjusted_grads = []
        for grad in grad_input:
            if grad is not None:
                grad_clipped = torch.clamp(grad, min=-1e-2, max=1e-2)
                adjusted_grads.append(grad_clipped * 0.05)
            else:
                adjusted_grads.append(None)
        return tuple(adjusted_grads)

    def _get_sampling_points(self, N, dtype, device):
        if dtype not in (torch.float32, torch.float16):
            raise ValueError(f"不支持的数据类型{dtype}")
        p_n_x = torch.tensor([0, 1, -1, 0, 0], dtype=dtype, device=device)[:N]
        p_n_y = torch.tensor([0, 0, 0, 1, -1], dtype=dtype, device=device)[:N]
        return torch.cat([p_n_x, p_n_y], 0).view(1, 2 * N, 1, 1)

    def _get_base_coords(self, h, w, N, dtype, device):
        max_coord = 1e5
        if h * self.stride > max_coord or w * self.stride > max_coord:
            raise ValueError(f"特征图尺寸过大（{h}×{w}）")
        
        grid_x = torch.arange(0, h * self.stride, self.stride, dtype=dtype, device=device)
        grid_y = torch.arange(0, w * self.stride, self.stride, dtype=dtype, device=device)
        grid_x, grid_y = torch.meshgrid(grid_x, grid_y, indexing='ij')
        
        p0_x = grid_y.flatten().view(1, 1, h, w).repeat(1, N, 1, 1)
        p0_y = grid_x.flatten().view(1, 1, h, w).repeat(1, N, 1, 1)
        return torch.cat([p0_x, p0_y], 1)

    def _get_final_coords(self, offset, dtype):
        N = offset.size(1) // 2
        h, w = offset.size(2), offset.size(3)
        device = offset.device
        
        sample_points = self._get_sampling_points(N, dtype, device)
        base_coords = self._get_base_coords(h, w, N, dtype, device)
        
        offset = offset.clamp(min=-2.0, max=2.0)
        final_coords = base_coords + sample_points + offset
        max_x = w * self.stride - 1
        max_y = h * self.stride - 1
        coords_x = final_coords[:, :N].clamp(min=0.0, max=float(max_x))
        coords_y = final_coords[:, N:].clamp(min=0.0, max=float(max_y))
        return torch.cat([coords_x, coords_y], dim=1).to(dtype)

    def _bilinear_sampling(self, x, coords, N):
        b, c, h, w = x.size()
        dtype = x.dtype
        device = x.device
        
        if h <= 0 or w <= 0:
            raise ValueError(f"无效特征图尺寸({h},{w})")
        
        coords = coords.permute(0, 2, 3, 1).contiguous()
        x_coords = coords[..., :N].clamp(0.0, float(w - 1))
        y_coords = coords[..., N:].clamp(0.0, float(h - 1))
        
        x0 = x_coords.floor().long().clamp(0, w - 1)
        x1 = (x0 + 1).clamp(0, w - 1)
        y0 = y_coords.floor().long().clamp(0, h - 1)
        y1 = (y0 + 1).clamp(0, h - 1)
        
        idx00 = (y0 * w + x0).clamp(0, h * w - 1)
        idx01 = (y1 * w + x0).clamp(0, h * w - 1)
        idx10 = (y0 * w + x1).clamp(0, h * w - 1)
        idx11 = (y1 * w + x1).clamp(0, h * w - 1)
        
        x0_float = x0.to(dtype)
        y0_float = y0.to(dtype)
        w00 = (1 - (x_coords - x0_float)) * (1 - (y_coords - y0_float)).clamp(0.0, 1.0)
        w01 = (1 - (x_coords - x0_float)) * (y_coords - y0_float).clamp(0.0, 1.0)
        w10 = (x_coords - x0_float) * (1 - (y_coords - y0_float)).clamp(0.0, 1.0)
        w11 = (x_coords - x0_float) * (y_coords - y0_float).clamp(0.0, 1.0)
        
        x_flat = x.contiguous().view(b, c, -1).clamp(min=-1e4, max=1e4)
        
        def gather_feature(idx):
            idx_expand = idx.unsqueeze(1).expand(-1, c, -1, -1, -1).view(b, c, -1)
            return x_flat.gather(dim=-1, index=idx_expand).view(b, c, h, w, N)
        
        x00 = gather_feature(idx00)
        x01 = gather_feature(idx01)
        x10 = gather_feature(idx10)
        x11 = gather_feature(idx11)
        
        out = (w00.unsqueeze(1) * x00 + 
               w01.unsqueeze(1) * x01 + 
               w10.unsqueeze(1) * x10 + 
               w11.unsqueeze(1) * x11)
        return out.clamp(min=-1e4, max=1e4)

    @staticmethod
    def _reshape_sampled_feature(x_sampled, num_param):
        b, c, h, w, n = x_sampled.shape
        if h * n < num_param:
            raise ValueError(f"采样后高度{h*n}小于卷积核尺寸{num_param}")
        return rearrange(x_sampled, 'b c h w n -> b c (h n) w')

    def forward(self, x):
        dtype = x.dtype
        device = x.device
        
        # 移除所有打印，仅保留异常处理逻辑
        if torch.isnan(x).any() or torch.isinf(x).any():
            x = x.clamp(min=-1e4, max=1e4)
        
        offset = self.offset_predict(x)
        if torch.isnan(offset).any() or torch.isinf(offset).any():
            offset = offset.clamp(min=-2.0, max=2.0)
        
        final_coords = self._get_final_coords(offset, dtype)
        if torch.isnan(final_coords).any() or torch.isinf(final_coords).any():
            final_coords = final_coords.clamp(min=0.0, max=float(max(final_coords.shape[2:]) * self.stride))
        
        x_sampled = self._bilinear_sampling(x, final_coords, self.num_param)
        if torch.isnan(x_sampled).any() or torch.isinf(x_sampled).any():
            x_sampled = x_sampled.clamp(min=-1e4, max=1e4)
        
        x_sampled_reshaped = self._reshape_sampled_feature(x_sampled, self.num_param)
        branch1_out = self.sample_conv_branch(x_sampled_reshaped)
        branch2_out = self.dw_pw_branch(x)
        
        if torch.isnan(branch1_out).any() or torch.isinf(branch1_out).any():
            branch1_out = branch1_out.clamp(min=-1e4, max=1e4)
        if torch.isnan(branch2_out).any() or torch.isinf(branch2_out).any():
            branch2_out = branch2_out.clamp(min=-1e4, max=1e4)
        
        if branch1_out.shape != branch2_out.shape:
            raise ValueError(f"双分支形状不匹配：{branch1_out.shape} vs {branch2_out.shape}")
        
        return (branch1_out + branch2_out).clamp(min=-1e4, max=1e4)


# SPPFCSPC（无调试打印）
class DAK_SPPF(nn.Module):
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5, k=(3, 5, 7)):
        super().__init__()
        c_mid = int(2 * c2 * e)
        self.shortcut = shortcut
        
        self.cv1 = Conv(c1, c_mid, 1, 1, g=g)
        self.cv3 = DRPAKConv(c_mid, c_mid, num_param=5, groups=g)
        self.cv4 = Conv(c_mid, c_mid, 1, 1, g=g)
        
        self.pools = nn.ModuleList([nn.MaxPool2d(ks, 1, ks//2) for ks in k if ks % 2 == 1 and ks <= 7])
        if not self.pools:
            self.pools = nn.ModuleList([nn.MaxPool2d(3, 1, 1)])
        
        self.cv2 = Conv(c1, c_mid, 1, 1, g=g)
        self.cv5 = Conv((len(self.pools) + 1) * c_mid, c_mid, 1, 1, g=g)
        self.cv6 = DRPAKConv(c_mid, c_mid, num_param=5, groups=g)
        self.cv7 = Conv(2 * c_mid, c2, 1, 1, g=g)
        
        if self.shortcut:
            self.res_conv = Conv(c1, c2, 1, 1, g=g)

    def forward(self, x):
        # 移除所有打印，仅保留异常处理
        if torch.isnan(x).any() or torch.isinf(x).any():
            x = x.clamp(min=-1e4, max=1e4)
        
        x1 = self.cv1(x)
        x1 = self.cv3(x1)
        x1 = self.cv4(x1)
        
        multi_scale_feats = [x1]
        for pool in self.pools:
            h, w = multi_scale_feats[-1].shape[2:]
            ks = pool.kernel_size[0] if isinstance(pool.kernel_size, tuple) else pool.kernel_size
            if h < ks or w < ks:
                continue  # 跳过不兼容的池化
            pooled = pool(multi_scale_feats[-1])
            if torch.isnan(pooled).any() or torch.isinf(pooled).any():
                pooled = pooled.clamp(min=-1e4, max=1e4)
            multi_scale_feats.append(pooled)
        
        cat_feats = torch.cat(multi_scale_feats, dim=1)
        if torch.isnan(cat_feats).any() or torch.isinf(cat_feats).any():
            cat_feats = cat_feats.clamp(min=-1e4, max=1e4)
        
        y1 = self.cv5(cat_feats)
        y1 = self.cv6(y1)
        y2 = self.cv2(x)
        
        cat_out = torch.cat([y1, y2], dim=1)
        out = self.cv7(cat_out)
        
        if self.shortcut:
            res = self.res_conv(x)
            if torch.isnan(res).any() or torch.isinf(res).any():
                res = res.clamp(min=-1e4, max=1e4)
            out = out + res
        
        return out.clamp(min=-1e4, max=1e4)


# 测试代码（无打印）
if __name__ == "__main__":
    import os
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    in_ch, out_ch = 512, 256
    batch, h, w = 2, 32, 32
    test_dtype = torch.float32
    
    model = DAK_SPPF(c1=in_ch, c2=out_ch, k=(3,5)).to(device, dtype=test_dtype)
    x = torch.randn(batch, in_ch, h, w, device=device, dtype=test_dtype, requires_grad=True)
    
    # 前向传播
    out = model(x)
    
    # 模型保存/加载
    model_path = "test_model.pth"
    torch.save(model.state_dict(), model_path)
    model_loaded = DAK_SPPF(c1=in_ch, c2=out_ch, k=(3,5)).to(device, dtype=test_dtype)
    model_loaded.load_state_dict(torch.load(model_path))
    os.remove(model_path)
    
    # 反向传播
    loss = out.sum()
    loss.backward()
