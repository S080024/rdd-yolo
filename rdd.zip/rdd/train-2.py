import warnings

warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO(r'/080038/sfh/RDD-YOLO/RDD-YOLO/ultralytics-main/yolo11-1.yaml')
    model.train(data=r'/080038/sfh/RDD-YOLO/RDD-YOLO/ultralytics-main/data-2.yaml',
                cache=False,
                imgsz=640,
                epochs=1,
                single_cls=False,  # 是否是单类别检测
                batch=8,
                close_mosaic=10,
                workers=0,
                device='',
                optimizer='SGD',
                amp=True,
                project='runs/train',
                name='exp',
                )
