from ultralytics.models import YOLO
import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

if __name__ == '__main__':
    model = YOLO(model='/080038/runs/train/exp438/weights/best.pt')
    model.val(data='/080038/sfh/RDD-YOLO/RDD-YOLO/ultralytics-main/data-2.yaml', split='val', batch=8, device='0', project='/runs/train', name='exp',
              half=False,)
