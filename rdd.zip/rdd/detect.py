# -*- coding: utf-8 -*-

import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    # model.load('yolo11n.pt') # 加载预训练权重,改进或者做对比实验时候不建议打开，因为用预训练模型整体精度没有很明显的提升
    model = YOLO(model=r'/080038/runs/train/exp438/weights/best.pt')
    model.predict( source='/080038/sfh/RDD-YOLO/RDD-YOLO/ultralytics-main/datasets/fagan/images/test',
                imgsz=640,
                device='0',
                project='/080038/sfh/RDD-YOLO/RDD-YOLO/ultralytics-main/runs/detect', 
                name='exp',
                save=True
                )
